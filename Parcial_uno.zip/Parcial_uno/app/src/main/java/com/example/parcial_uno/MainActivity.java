package com.example.parcial_uno;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {


    EditText edt_usuario, edt_contraseña;
    Button btn_ingresar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        edt_usuario = findViewById(R.id.edt_usuario);
        edt_contraseña = findViewById(R.id.edt_contraseña);
        btn_ingresar = findViewById(R.id.btn_ingresar);


        btn_ingresar.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view)
            {

                String usuario = edt_usuario.getText().toString();
                String contraseña = edt_contraseña.getText().toString();


                if (usuario.isEmpty() || contraseña.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Faltan datos por llenar", Toast.LENGTH_SHORT).show();
                }
                else
                {

                    if (usuario.equals("uac123") && contraseña.equals("12345678")) {

                        Intent intent = new Intent(MainActivity.this, Pantalla_dos.class);
                        startActivity(intent);
                    }
                    else
                    {

                        Toast.makeText(MainActivity.this, "Usuario o contraseña incorrecta", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}