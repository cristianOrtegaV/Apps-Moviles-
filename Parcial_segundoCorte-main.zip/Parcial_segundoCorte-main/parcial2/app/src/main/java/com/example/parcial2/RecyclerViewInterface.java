package com.example.parcial2;

public interface RecyclerViewInterface {
    void onItemClick(int position);

}
