package com.example.pruebaadaptador.clases;

public interface RecyclerViewInterface {
    void onItemClick(int position);
}
