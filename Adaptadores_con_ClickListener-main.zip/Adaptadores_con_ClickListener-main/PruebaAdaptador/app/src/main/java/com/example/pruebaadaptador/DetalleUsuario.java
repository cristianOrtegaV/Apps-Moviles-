package com.example.pruebaadaptador;

public class DetalleUsuario {
}
