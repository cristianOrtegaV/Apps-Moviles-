package com.example.pruebaadaptador;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class MainActivity2 extends AppCompatActivity {

    TextView nombreTextView, txt_curso_usuario2;
    ImageView img_usuario2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        String nombre = getIntent().getStringExtra("nombre_usuario");
        String curso = getIntent().getStringExtra("curso_usuario");
        String imagen = getIntent().getStringExtra("imagen_usuario");

        nombreTextView = findViewById(R.id.txt_nombre_usuario2);
        txt_curso_usuario2 = findViewById(R.id.txt_curso_usuario2);
        img_usuario2 = findViewById(R.id.img_usuario2);

        nombreTextView.setText(nombre);
        txt_curso_usuario2.setText(curso);
        Picasso.get().load(imagen).into(img_usuario2);



    }
}