package com.example.pruebaadaptador;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;

import com.example.pruebaadaptador.adaptadores.UsuarioAdaptador;
import com.example.pruebaadaptador.clases.RecyclerViewInterface;
import com.example.pruebaadaptador.clases.Usuario;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements RecyclerViewInterface {

    RecyclerView rcv_usuarios;
    List<Usuario> listaUsuarios = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rcv_usuarios = findViewById(R.id.rev_usuarios);

        Usuario usu1 = new Usuario("https://rickandmortyapi.com/api/character/avatar/72.jpeg","William","Movil");
        Usuario usu2 = new Usuario("https://rickandmortyapi.com/api/character/avatar/120.jpeg","Fernando","junior");
        Usuario usu3 = new Usuario("https://rickandmortyapi.com/api/character/avatar/190.jpeg","Lopez","estral");
        Usuario usu4 = new Usuario("https://rickandmortyapi.com/api/character/avatar/241.jpeg","Vasquez","ED");

        listaUsuarios.add(usu1);
        listaUsuarios.add(usu2);
        listaUsuarios.add(usu3);
        listaUsuarios.add(usu4);

        rcv_usuarios.setLayoutManager(new LinearLayoutManager(this));
        rcv_usuarios.setAdapter(new UsuarioAdaptador(listaUsuarios, this));


    }

    @Override
    public void onItemClick(int position) {
        Intent intent = new Intent(MainActivity.this, MainActivity2.class);
        intent.putExtra("nombre_usuario", listaUsuarios.get(position).getNombre());
        intent.putExtra("curso_usuario", listaUsuarios.get(position).getCurso());
        intent.putExtra("imagen_usuario", listaUsuarios.get(position).getImagen());

        startActivity(intent);
    }
}