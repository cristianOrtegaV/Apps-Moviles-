package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button btn_sumar;
    EditText edt_num1, edt_num2;
    Spinner spinner_operations;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_sumar = findViewById(R.id.btn_sumar);
        edt_num1 = findViewById(R.id.edt_num1);
        edt_num2 = findViewById(R.id.edt_num2);
        spinner_operations = findViewById(R.id.spinner_operations);

        // Spinner con las distintas operaciones
        String[] operations = {"Sumar", "Restar", "Multiplicar", "Dividir"};

        //se usa esto pq asi puede ser usada por el spinner sin importar que tipo de dato sea
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, operations);

        //aqui le dice al spinner como tiene q lucir cuando se seleccione en la ui
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner_operations.setAdapter(adapter);

        btn_sumar.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                String text1 = edt_num1.getText().toString();
                String text2 = edt_num2.getText().toString();
                String selectedOperation = spinner_operations.getSelectedItem().toString();

                if (text1.equals("") || text2.equals("")) {
                    Toast.makeText(MainActivity.this, "Los datos están vacíos", Toast.LENGTH_LONG).show();
                }
                else
                {
                    double num1 = Double.parseDouble(text1);
                    double num2 = Double.parseDouble(text2);
                    double result = 0;

                    switch (selectedOperation) {
                        case "Sumar":
                            result = num1 + num2;
                            break;
                        case "Restar":
                            result = num1 - num2;
                            break;
                        case "Multiplicar":
                            result = num1 * num2;
                            break;
                        case "Dividir":
                            if (num2 != 0) {
                                result = num1 / num2;
                            } else {
                                Toast.makeText(MainActivity.this, "No se puede dividir por 0", Toast.LENGTH_LONG).show();
                                return;
                            }
                            break;
                    }

                    //ya no se muestra el resultado en la misma pantalla sino q se manda a la otra
                    Intent intent = new Intent(MainActivity.this, ResultActivity.class);
                    intent.putExtra("RESULTADO BRODDER", String.valueOf(result));
                    startActivity(intent);


                    //Toast.makeText(MainActivity.this, "El resultado es: " + result, Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}