package com.example.myapplication;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ResultActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        TextView resultTextView = findViewById(R.id.result_text_view);

        // aqui se consigue el resultado del Intent
        String result = getIntent().getStringExtra("RESULTADO BRODDER");

        // Muestra el resultado en el TextView
        resultTextView.setText("El resultado es: " + result);
    }
}